﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGames
{
    class Card
    {

        private string type;
        private string suit;

        public Card(string type, string suit)
        {
            this.type = type;
            this.suit = suit;
        }

        public string Type { get => type; set => type = value; }
        public string Suit { get => suit; set => suit = value; }
    }
}
