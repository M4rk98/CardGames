﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGames
{
    class Program
    {


        static void Main(string[] args)
        {

            Durak game = new Durak();
            /*
            for (int i = 0; i < game.Deck.Count; i++)
            {
                Console.WriteLine(game.Deck[i].Suit + " - " + game.Deck[i].Type);
            }
            */
            game.displayMenu();

            Console.ReadKey();
        }



    }
}
