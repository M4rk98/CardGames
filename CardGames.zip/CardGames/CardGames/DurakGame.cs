﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGames
{
    class Durak
    {
        private List<Card> deck = new List<Card>();
        private List<Player> players = new List<Player>();

        private List<Card> current_cards = new List<Card>();

        //Makk (Acorns), Zöld (Leaves), Piros (Hearts) and Tök (Balls, originally Bells)
        private readonly String[] suits = new String[] { "Acorns", "Leaves", "Hearts", "Balls" };
        private readonly String[] types = new string[] { "Ace", "King", "Over", "Under", "10", "9", "8", "7" };
    
        internal List<Card> Deck { get => deck; }

        private void initializeGame()
        {
            for (int i = 0; i < suits.GetLength(0); i++)
            {
                for (int j = 0; j < types.GetLength(0); j++)
                {
                    deck.Add(new Card(types[j], suits[i]));
                }
            }


            Console.WriteLine();
            Console.Write("2. Please select the number of players: ");
            int numberOfPlayers = int.Parse(Console.ReadLine());


            for (int i = 0; i < numberOfPlayers; i++)
            {
                Console.WriteLine("");
                Console.Write("Kérlek add meg a(z) " + i + ". játékos nevét: ");
                
                string playerName = Console.ReadLine();

                while (playerName == "")
                {
                    Console.WriteLine("");
                    Console.Write("Kérlek add meg a(z) " + i + ". játékos nevét: ");
                    playerName = Console.ReadLine();
                }

                players.Add(new Player(playerName, i));
            }

            Console.WriteLine("Number of deck: " + deck.Count);

            Console.WriteLine();
            Random rnd = new Random();

            for (int i = 0; i < players.Count; i++)
            {
                for (int j = 0; j < numberOfPlayers; j++)
                {
                    int cardForStart = rnd.Next(0, deck.Count);
                    players[i].Hand.Add(deck[cardForStart]);
                    deck.RemoveAt(cardForStart);

                }
                
            }

            int start = rnd.Next(0, deck.Count);
            current_cards.Add(deck[start]);
            deck.RemoveAt(start);

            for (int i = 0; i < current_cards.Count; i++)
            {
                Console.WriteLine("Number of deck: " + deck.Count);
                Console.WriteLine(current_cards[i].Type + " - " + current_cards[i].Suit);
            }

            this.start();


        }

        public void start()
        {
            bool isWinner = false;

            Random rnd = new Random();
            /*
            int first_player_card = rnd.Next(0, players[0].Hand.Count);
            current_cards.Add(players[0].Hand[first_player_card]);
            players[0].Hand.RemoveAt(first_player_card);

            Console.WriteLine(players.Count);

            */
            

            while (!isWinner)
            {
                for (int i = 0; i < players.Count; i++)
                {
                    var j = 0;

                    //bool isPut = Array.IndexOf(players[i].Hand[j]);

                    while(j < players[i].Hand.Count-1 && !isPut)
                    {

                        Console.WriteLine(players[i].Hand[j].Type);
                        j++;
                    }

                    Console.WriteLine(players[i].Hand.Count);
                    players[i].put(current_cards, players[i].Hand[j]);
                    Console.WriteLine(players[i].Hand.Count);


                }

                isWinner = true;

            }



        }


        public void displayMenu()
        {
            Console.WriteLine("**** Welcome to Durak card game! ****");
            Console.WriteLine();
            Console.WriteLine("1. Please choose from the options below");
            Console.WriteLine("Start the game: 1 \nPrevious games: 2");
            Console.Write("Your choice: ");

            int choice = int.Parse(Console.ReadLine());

            switch(choice)
            {
                case 1:
                    initializeGame();
                    break;
                default:
                    Console.WriteLine("Default");
                    break;
            }
        }

    }
}
