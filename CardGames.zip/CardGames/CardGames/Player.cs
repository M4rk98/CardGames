﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGames
{
    class Player
    {
        private string name;
        private int order;

        private List<Card> hand = new List<Card>();

        public Player(string name, int order)
        {
            this.name = name;
            this.order = order;
        }

        public string Name { get => name; }
        public int Order { get => order; }
        internal List<Card> Hand { get => hand; set => hand = value; }

        public void put(List<Card> table, Card card)
        {
            table.Add(card);
            this.hand.Remove(card);
        }

    }
}
